#include <ntddk.h>

DRIVER_INITIALIZE	DriverEntry;
DRIVER_UNLOAD		OnUnload;
