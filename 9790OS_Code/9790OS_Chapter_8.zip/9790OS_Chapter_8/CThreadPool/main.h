#ifndef __MAIN__
#define __MAIN__

#include <Windows.h>
#include <tchar.h>
#include <time.h>

#define	MSG_ENDTASK    0x1000
#define	MAX_WAIT_TIME  120 * 1000

#endif
