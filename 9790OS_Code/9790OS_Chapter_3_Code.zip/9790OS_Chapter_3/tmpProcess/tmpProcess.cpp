#include "stdafx.h"
#include <iostream>

int _tmain(int argc, _TCHAR* argv[])
{
	std::cout << "Hello. I am a very simple process."
		<< std::endl
		<< "I am used to demonstrate process creation."
		<< std::endl;

	return 0;
}
